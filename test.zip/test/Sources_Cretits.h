/*
   Hardware Library for 128x128 GLCD: https://github.com/sumotoy/TFT_ILI9163C
   Author/Ref: http://forum.pjrc.com/threads/25862-ILI9163C-128x128-TFT-driver
   
   Adafruit (Ladyada) Graphic core: https://github.com/adafruit/Adafruit-GFX-Library
   
   GLCD source: http://www.ebay.com/itm/310876068105

*/
