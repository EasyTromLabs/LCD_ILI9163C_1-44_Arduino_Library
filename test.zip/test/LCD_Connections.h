/*
GLCD                     Signal           Arduino 328P
J2#                        Name           Pin / Signal
1 . . . . . . . . . . . .  Vcc . . . . .  Pin#27 on Nano
2 . . . . . . . . . . . .  GND . . . . .  Pin#29 on Nano
3 . . . . . . . . . . . .   CS . . . . .  D10
4 . . . . . . . . . . . .  Reset . . . .  D12
5 . . . . . . . . . . . .  DC(A0). . . .   D9
6 . . . . . . . . . . . .  MOSI(SDA) . .  D11
7 . . . . . . . . . . . .  SCLK(SCK) . .  D13
8 . . . . . . . . . . . .  LED Backlight  3.3 Vcc (Verify 10 Ohm on display)

Note: This example sketch and wiring REQUIRES that the Nano be run at 3.3V maximum
*/
